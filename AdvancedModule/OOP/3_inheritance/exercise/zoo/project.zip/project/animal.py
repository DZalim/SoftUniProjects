class Animal:

    def __init__(self, name):
        self.name = name
        